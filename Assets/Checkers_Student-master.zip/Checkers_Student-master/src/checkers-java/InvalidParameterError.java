
public class InvalidParameterError extends Exception{
	public InvalidParameterError() {};
}
