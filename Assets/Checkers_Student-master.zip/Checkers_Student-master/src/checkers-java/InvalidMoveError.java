public class InvalidMoveError extends Exception {
    public InvalidMoveError() {
        System.out.println("Invalid Move Error");
    }
}
