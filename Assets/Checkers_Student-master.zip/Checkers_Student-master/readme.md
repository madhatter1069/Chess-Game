# CS-171 Checkers Project
Current Version: 1.1.0.11052019
# 10/28/2019
Fixed a bug in **python** shell that Board parameter should be (col,row) instead of (row,col) 
# 10/29/2019
Fixed java copy constructor
# 10/30/2019
Fixed **cpp/java** undo function causing the wrong attributes of checkers. <br>
Fixed **cpp/java** undo black counter and white counter.<br>
Fixed **java** undo function (equal problem)<br>
Make counters in **cpp/java/python** more stable.<br>
# 11/05/2019
Added a new feature (**cpp/java/python**): "self play mode" which can be used to debug more efficiently.
# 11/14/2019
This update is about Poor AI:
1. Added support for 3.6.8
2. Fix some problem that causes Poor AI crashing in some rare cases.

# 11/30/2019
Added the Good AI.

# 12/05/2019
Blocked some invalid moves.
